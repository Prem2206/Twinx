package com.twinx.ai.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinx.ai.model.AssistantState
import com.twinx.ai.model.ChatMessage
import com.twinx.ai.model.LanguageMode
import com.twinx.ai.model.Role
import com.twinx.ai.ui.components.AiOrb
import com.twinx.ai.ui.components.MicButton
import com.twinx.ai.ui.theme.TwinXColors
import com.twinx.ai.ui.theme.stateColor

@Composable
fun HomeScreen(
    ui: HomeUiState,
    onMicTap: () -> Unit,
    onOpenSettings: () -> Unit,
    onLanguage: (LanguageMode) -> Unit,
    onPreviewState: (AssistantState) -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(TwinXColors.Void)
            .safeDrawingPadding()
            .padding(horizontal = 20.dp, vertical = 8.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "TWINX AI",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TwinXColors.Ice
                )
                Text(
                    "Your Personal Voice Assistant",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TwinXColors.Muted
                )
            }
            IconButton(onClick = onOpenSettings) {
                Icon(Icons.Filled.Settings, contentDescription = "Open settings", tint = TwinXColors.Ice)
            }
        }

        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            StatusPill(ui.assistantState)
        }

        AiOrb(
            state = ui.assistantState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        )

        ConversationPanel(
            messages = ui.messages,
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
        )

        Spacer(Modifier.height(10.dp))
        Text("Animation preview (Phase 1 only)", style = MaterialTheme.typography.bodySmall, color = TwinXColors.Muted)
        Spacer(Modifier.height(4.dp))
        ChipRow(
            items = AssistantState.entries.toList(),
            isSelected = { it == ui.assistantState },
            label = { it.label },
            onClick = onPreviewState
        )

        Spacer(Modifier.height(10.dp))
        Text("Language", style = MaterialTheme.typography.bodySmall, color = TwinXColors.Muted)
        Spacer(Modifier.height(4.dp))
        ChipRow(
            items = LanguageMode.entries.toList(),
            isSelected = { it == ui.language },
            label = { it.label },
            onClick = onLanguage
        )

        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            MicButton(state = ui.assistantState, onClick = onMicTap)
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun StatusPill(state: AssistantState) {
    val color by animateColorAsState(stateColor(state), label = "pillColor")
    val shape = RoundedCornerShape(50)
    Row(
        Modifier
            .clip(shape)
            .background(TwinXColors.Panel)
            .border(1.dp, color.copy(alpha = 0.5f), shape)
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .semantics { liveRegion = LiveRegionMode.Polite },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(Modifier.size(8.dp))
        Text(state.label, style = MaterialTheme.typography.labelLarge, color = TwinXColors.Ice)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun <T> ChipRow(
    items: List<T>,
    isSelected: (T) -> Boolean,
    label: (T) -> String,
    onClick: (T) -> Unit
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        items.forEach { item ->
            FilterChip(
                selected = isSelected(item),
                onClick = { onClick(item) },
                label = {
                    Text(
                        label(item),
                        fontSize = 12.sp,
                        maxLines = 1,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    containerColor = TwinXColors.Panel,
                    labelColor = TwinXColors.Muted,
                    selectedContainerColor = TwinXColors.Cyan.copy(alpha = 0.2f),
                    selectedLabelColor = TwinXColors.Ice
                ),
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun ConversationPanel(messages: List<ChatMessage>, modifier: Modifier = Modifier) {
    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier
            .clip(shape)
            .background(TwinXColors.Panel)
            .border(1.dp, TwinXColors.Edge, shape)
    ) {
        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages, key = { it.id }) { Bubble(it) }
        }
    }
}

@Composable
private fun Bubble(message: ChatMessage) {
    if (message.role == Role.SYSTEM) {
        Text(
            message.text,
            style = MaterialTheme.typography.bodySmall,
            color = TwinXColors.Muted,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        return
    }
    val fromUser = message.role == Role.USER
    Box(
        Modifier.fillMaxWidth(),
        contentAlignment = if (fromUser) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Text(
            message.text,
            style = MaterialTheme.typography.bodyMedium,
            color = TwinXColors.Ice,
            modifier = Modifier
                .widthIn(max = 260.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(
                    if (fromUser) TwinXColors.Blue.copy(alpha = 0.35f)
                    else TwinXColors.Cyan.copy(alpha = 0.12f)
                )
                .padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }
}
