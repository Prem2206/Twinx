package com.twinx.ai.ui

import androidx.lifecycle.ViewModel
import com.twinx.ai.model.AssistantState
import com.twinx.ai.model.ChatMessage
import com.twinx.ai.model.LanguageMode
import com.twinx.ai.model.Role
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class HomeUiState(
    val assistantState: AssistantState = AssistantState.OFFLINE,
    val language: LanguageMode = LanguageMode.AUTO,
    val messages: List<ChatMessage> = listOf(
        ChatMessage(
            id = 0,
            role = Role.SYSTEM,
            text = "Voice input is not connected yet (Phase 2). " +
                "The mic button and state chips only preview the interface."
        )
    )
)

class HomeViewModel : ViewModel() {

    private val _ui = MutableStateFlow(HomeUiState())
    val ui: StateFlow<HomeUiState> = _ui.asStateFlow()

    fun previewState(state: AssistantState) {
        _ui.update { it.copy(assistantState = state) }
    }

    fun onMicTap() {
        _ui.update {
            val next = if (it.assistantState == AssistantState.OFFLINE) {
                AssistantState.LISTENING
            } else {
                AssistantState.OFFLINE
            }
            it.copy(assistantState = next)
        }
    }

    fun setLanguage(mode: LanguageMode) {
        _ui.update { it.copy(language = mode) }
    }
}
