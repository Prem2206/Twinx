package com.twinx.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.twinx.ai.model.LanguageMode
import com.twinx.ai.ui.theme.TwinXColors

@Composable
fun SettingsScreen(
    language: LanguageMode,
    onLanguage: (LanguageMode) -> Unit,
    onBack: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(TwinXColors.Void)
            .safeDrawingPadding()
            .padding(horizontal = 20.dp, vertical = 8.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = TwinXColors.Ice
                )
            }
            Text("Settings", style = MaterialTheme.typography.titleMedium, color = TwinXColors.Ice)
        }

        Section("Preferred language")
        LanguageMode.entries.forEach { mode ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .selectable(
                        selected = mode == language,
                        role = Role.RadioButton,
                        onClick = { onLanguage(mode) }
                    )
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = mode == language,
                    onClick = null,
                    colors = RadioButtonDefaults.colors(
                        selectedColor = TwinXColors.Cyan,
                        unselectedColor = TwinXColors.Muted
                    )
                )
                Column(Modifier.padding(start = 12.dp)) {
                    Text(mode.label, style = MaterialTheme.typography.bodyMedium, color = TwinXColors.Ice)
                    Text(mode.description, style = MaterialTheme.typography.bodySmall, color = TwinXColors.Muted)
                }
            }
        }
        Body("This choice is kept only while the app is open. Saving it comes in Phase 3.")

        Section("Microphone")
        Body(
            "TwinX will ask for microphone access the first time you tap the mic, " +
                "not at install. Audio is processed on your device by default."
        )

        Section("Battery")
        Body(
            "Listening for \"Hey TwinX\" keeps the microphone open and uses more battery. " +
                "Wake-word listening will be off by default, and push-to-talk will always be available."
        )

        Section("This build")
        Body("TwinX AI 0.1.0, Phase 1: interface only. Voice, speech, AI and device actions are not connected yet.")
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Section(title: String) {
    Spacer(Modifier.height(20.dp))
    Text(title, style = MaterialTheme.typography.titleMedium, color = TwinXColors.Cyan)
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun Body(text: String) {
    Text(text, style = MaterialTheme.typography.bodyMedium, color = TwinXColors.Muted)
}
