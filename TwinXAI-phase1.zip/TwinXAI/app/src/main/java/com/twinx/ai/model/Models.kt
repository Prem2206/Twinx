package com.twinx.ai.model

enum class AssistantState(val label: String) {
    OFFLINE("Offline"),
    LISTENING("Listening"),
    PROCESSING("Processing"),
    SPEAKING("Speaking")
}

enum class LanguageMode(val label: String, val description: String) {
    AUTO("Auto", "Detect Tamil, English, or mixed Tanglish automatically"),
    TAMIL("தமிழ்", "Always expect and reply in Tamil"),
    ENGLISH("English", "Always expect and reply in English")
}

enum class Role { USER, ASSISTANT, SYSTEM }

data class ChatMessage(
    val id: Long,
    val role: Role,
    val text: String
)
