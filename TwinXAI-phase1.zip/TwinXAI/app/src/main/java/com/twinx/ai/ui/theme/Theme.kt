package com.twinx.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.twinx.ai.model.AssistantState

object TwinXColors {
    val Void = Color(0xFF040B14)
    val Panel = Color(0xFF0A1726)
    val Edge = Color(0xFF16324D)
    val Cyan = Color(0xFF22D3EE)
    val Blue = Color(0xFF3B82F6)
    val Ice = Color(0xFFD7F3FF)
    val Muted = Color(0xFF7C93A8)
    val Slate = Color(0xFF4B6A88)
    val Pale = Color(0xFF67E8F9)
}

fun stateColor(state: AssistantState): Color = when (state) {
    AssistantState.OFFLINE -> TwinXColors.Slate
    AssistantState.LISTENING -> TwinXColors.Cyan
    AssistantState.PROCESSING -> TwinXColors.Blue
    AssistantState.SPEAKING -> TwinXColors.Pale
}

private val scheme = darkColorScheme(
    primary = TwinXColors.Cyan,
    onPrimary = TwinXColors.Void,
    secondary = TwinXColors.Blue,
    background = TwinXColors.Void,
    onBackground = TwinXColors.Ice,
    surface = TwinXColors.Panel,
    onSurface = TwinXColors.Ice,
    outline = TwinXColors.Edge
)

private val typography = Typography(
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Light,
        fontSize = 30.sp,
        letterSpacing = 8.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 16.sp,
        letterSpacing = 0.5.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontSize = 12.sp,
        lineHeight = 17.sp
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp
    )
)

@Composable
fun TwinXTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = typography, content = content)
}
