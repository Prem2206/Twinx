package com.twinx.ai.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.twinx.ai.model.AssistantState
import com.twinx.ai.ui.theme.TwinXColors
import com.twinx.ai.ui.theme.stateColor

@Composable
fun MicButton(state: AssistantState, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val color by animateColorAsState(stateColor(state), label = "micColor")
    val active = state != AssistantState.OFFLINE
    Box(
        modifier = modifier
            .size(76.dp)
            .clip(CircleShape)
            .background(if (active) color.copy(alpha = 0.18f) else TwinXColors.Panel)
            .border(2.dp, color, CircleShape)
            .clickable(
                onClickLabel = if (active) "Stop listening" else "Start listening",
                role = Role.Button,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        MicGlyph(
            color = if (active) TwinXColors.Ice else color,
            modifier = Modifier.size(32.dp)
        )
    }
}

/** Hand-drawn microphone so no extended icon library is needed. */
@Composable
fun MicGlyph(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val sw = w * 0.08f
        drawRoundRect(
            color = color,
            topLeft = Offset(w * 0.36f, h * 0.08f),
            size = Size(w * 0.28f, h * 0.5f),
            cornerRadius = CornerRadius(w * 0.14f)
        )
        drawArc(
            color = color,
            startAngle = 0f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = Offset(w * 0.22f, h * 0.2f),
            size = Size(w * 0.56f, h * 0.5f),
            style = Stroke(width = sw, cap = StrokeCap.Round)
        )
        drawLine(color, Offset(w * 0.5f, h * 0.7f), Offset(w * 0.5f, h * 0.88f), sw, StrokeCap.Round)
        drawLine(color, Offset(w * 0.36f, h * 0.9f), Offset(w * 0.64f, h * 0.9f), sw, StrokeCap.Round)
    }
}
