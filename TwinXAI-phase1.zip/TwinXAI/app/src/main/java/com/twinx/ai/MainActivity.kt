package com.twinx.ai

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.twinx.ai.ui.HomeScreen
import com.twinx.ai.ui.HomeViewModel
import com.twinx.ai.ui.SettingsScreen
import com.twinx.ai.ui.theme.TwinXTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        )
        setContent {
            TwinXTheme { TwinXApp() }
        }
    }
}

@Composable
fun TwinXApp(vm: HomeViewModel = viewModel()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    var showSettings by rememberSaveable { mutableStateOf(false) }

    BackHandler(enabled = showSettings) { showSettings = false }

    if (showSettings) {
        SettingsScreen(
            language = ui.language,
            onLanguage = vm::setLanguage,
            onBack = { showSettings = false }
        )
    } else {
        HomeScreen(
            ui = ui,
            onMicTap = vm::onMicTap,
            onOpenSettings = { showSettings = true },
            onLanguage = vm::setLanguage,
            onPreviewState = vm::previewState
        )
    }
}
