package com.twinx.ai.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import com.twinx.ai.model.AssistantState
import com.twinx.ai.ui.theme.TwinXColors
import com.twinx.ai.ui.theme.stateColor
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Central animated orb. One Canvas, three infinite animations, so it stays cheap.
 * Offline: slow and dim. Listening: wide reactive ring. Processing: fast spinning arcs.
 * Speaking: strongest ring motion.
 */
@Composable
fun AiOrb(state: AssistantState, modifier: Modifier = Modifier) {
    val accent by animateColorAsState(stateColor(state), tween(500), label = "orbColor")
    val energy by animateFloatAsState(
        targetValue = when (state) {
            AssistantState.OFFLINE -> 0.12f
            AssistantState.LISTENING -> 0.75f
            AssistantState.PROCESSING -> 0.3f
            AssistantState.SPEAKING -> 1f
        },
        animationSpec = tween(600),
        label = "orbEnergy"
    )

    val loopMs = when (state) {
        AssistantState.OFFLINE -> 9000
        AssistantState.LISTENING -> 3600
        AssistantState.PROCESSING -> 1800
        AssistantState.SPEAKING -> 2400
    }
    val spinMs = when (state) {
        AssistantState.OFFLINE -> 24000
        AssistantState.LISTENING -> 12000
        AssistantState.PROCESSING -> 2200
        AssistantState.SPEAKING -> 8000
    }
    val pulseMs = when (state) {
        AssistantState.OFFLINE -> 3200
        AssistantState.LISTENING -> 1100
        AssistantState.PROCESSING -> 900
        AssistantState.SPEAKING -> 600
    }

    val transition = rememberInfiniteTransition(label = "orb")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(loopMs, easing = LinearEasing)),
        label = "phase"
    )
    val spin by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(spinMs, easing = LinearEasing)),
        label = "spin"
    )
    val pulse by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(pulseMs, easing = FastOutSlowInEasing),
            RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Canvas(
        modifier
            .fillMaxSize()
            .semantics { contentDescription = "TwinX AI orb, ${state.label}" }
    ) {
        val c = center
        val r = size.minDimension / 2f
        val breathe = 1f + 0.06f * pulse * (0.5f + energy)

        // Outer glow
        drawCircle(
            brush = Brush.radialGradient(
                listOf(accent.copy(alpha = 0.22f), Color.Transparent),
                center = c,
                radius = r
            ),
            radius = r,
            center = c
        )

        // Radial bars (the voice visualizer)
        val bars = 72
        val inner = r * 0.80f
        val barWidth = (r * 0.012f).coerceAtLeast(2f)
        for (i in 0 until bars) {
            val a = (i.toFloat() / bars) * 2f * PI.toFloat()
            val w1 = 0.5f + 0.5f * sin(a * 6f + phase)
            val w2 = 0.5f + 0.5f * sin(a * 11f - phase * 2f)
            val len = r * 0.025f + r * 0.13f * energy * (0.6f * w1 + 0.4f * w2)
            val ca = cos(a)
            val sa = sin(a)
            drawLine(
                color = accent.copy(alpha = 0.35f + 0.65f * w1),
                start = Offset(c.x + ca * inner, c.y + sa * inner),
                end = Offset(c.x + ca * (inner + len), c.y + sa * (inner + len)),
                strokeWidth = barWidth,
                cap = StrokeCap.Round
            )
        }

        // Thin ring
        drawCircle(
            color = accent.copy(alpha = 0.35f),
            radius = r * 0.70f,
            center = c,
            style = Stroke(width = 1.5f)
        )

        // Rotating arcs
        val arcR = r * 0.62f
        val sweep = if (state == AssistantState.PROCESSING) 80f else 50f
        for (i in 0 until 3) {
            drawArc(
                color = accent,
                startAngle = spin + i * 120f,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = Offset(c.x - arcR, c.y - arcR),
                size = Size(arcR * 2f, arcR * 2f),
                style = Stroke(width = r * 0.02f, cap = StrokeCap.Round)
            )
        }
        val arcR2 = r * 0.52f
        for (i in 0 until 2) {
            drawArc(
                color = TwinXColors.Blue.copy(alpha = 0.7f),
                startAngle = -spin * 1.5f + i * 180f,
                sweepAngle = 30f,
                useCenter = false,
                topLeft = Offset(c.x - arcR2, c.y - arcR2),
                size = Size(arcR2 * 2f, arcR2 * 2f),
                style = Stroke(width = r * 0.014f, cap = StrokeCap.Round)
            )
        }

        // Core
        val coreR = r * 0.42f * breathe
        drawCircle(
            brush = Brush.radialGradient(
                listOf(
                    TwinXColors.Ice.copy(alpha = 0.85f),
                    accent.copy(alpha = 0.85f),
                    accent.copy(alpha = 0.15f),
                    Color.Transparent
                ),
                center = c,
                radius = coreR * 1.5f
            ),
            radius = coreR * 1.5f,
            center = c
        )
    }
}
